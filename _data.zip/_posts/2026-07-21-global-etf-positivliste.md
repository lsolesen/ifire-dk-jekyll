---
title: "Bedste ETF'er til FIRE: Lagerbeskatning og aktieindkomst"
description: "Vil du bygge en ultrabillig global portefølje? Få den dybdegående guide til udenlandske ETF'er på SKATs positivliste og optimering af aktieindkomst."
permalink: /bedste-etfer-fire-lagerbeskatning/
categories: [Investering, FIRE]
tags: [ETF, Skat, Lagerbeskatning, Passiv indkomst]
---

> **Hurtig guide: Er du landet det rette sted?**
> * Hvis du vil undgå den årlige lagerskat og udskyde skatten på dine frie midler, så læs i stedet om [danske realisationsbeskattede fonde](/danske-investeringsforeninger-fire-realisation/).
> * Hvis du leder efter den hemmelige skatte-bobler til børns frikort eller modregning i renteudgifter, så hop til min [guide til kapitalbeskattede fonde](/guide-kapitalbeskattede-fonde-skat/).

Når du opbygger fundamentet for din økonomiske uafhængighed (FIRE), er der ét altoverskyggende princip, der går igen hos de mest succesfulde investorer: Enkelhed og ultrabred spredning. I stedet for at forsøge at finde nålen i højstakken, køber vi hele højstakken. 

Det er der en helt særlig, statistisk årsag til. Historiske data viser, at enkeltaktier har en markant tendens til at underperforme markedsindekset som helhed. Hvis du misser de absolut bedste top-aktier, risikerer du et afkast tæt på nul. Derfor satser vi på at ramme verdensmarkedet så bredt som overhovedet muligt via passiv indeksinvestering. Du kan læse meget mere om denne vigtige pointe og min filosofi i min artikel om [verdensmarkedet og den brede portefølje](/investering-vol9/).

I denne artikel kigger vi nærmere på, hvordan du sammensætter et globalt setup udelukkende med udenlandske ETF'er (*Exchange Traded Funds*), der er godkendt til **aktieindkomst**.

---

## Hvorfor vælge udenlandske ETF'er på positivlisten?

Den absolut største fordel ved udenlandske ETF'er er de ekstremt lave omkostninger. Hvor danske investeringsforeninger ofte tager sig godt betalt for administration, kan du i udlandet finde fonde, der dækker hele verden til en brøkdel af prisen (ofte helt ned til en ÅOP på 0,05 % – 0,22 %). Over en lang FIRE-tidshorisont betyder de sparede omkostninger alverden for renters rente-effekten.

Udenlandske ETF'er på SKATs positivliste afregnes efter **lagerprincippet som aktieindkomst**. Det betyder, at du hvert år betaler skat af din urealiserede gevinst, uanset om du har solgt ud eller ej. 

### Det ideelle match: Aktiesparekontoen og pensionsdepoter
Fordi disse fonde *skal* lagerbeskattes, har de deres absolutte primære berettigelse i de miljøer, der i forvejen er født med lagerbeskatning, men som tilbyder en markant lavere skattesats end almindelige frie midler:

* **Aktiesparekontoen (ASK):** Her slipper du med en flad lagerbeskatning på kun 17 % (i stedet for de normale 27/42 % på et frit depot).
* **Pensionsdepoter (Aldersopsparing, Ratepension m.m.):** Her er skatten helt nede på 15,3 % (PAL-skat) via lagerprincippet.

I disse depoter er de udenlandske ETF'er på positivlisten kongen. Du får udlandets ultralave omkostninger, og du bliver ikke straffet ekstra for lagerbeskatningen, fordi depotet alligevel kræver det. Din absolutte førsteprioritet bør derfor altid være at maxe disse depoter ud med billige ETF'er først. Du kan læse min specifikke strategi for dette i min artikel om [Aktiesparekontoen](/aktiesparekonto/).

### Hvad så med frie midler på et almindeligt depot?
Det er først det sekund, du har fyldt din ASK og dine pensionsdepoter, at du skal overveje, om de udenlandske ETF'er skal have en plads blandt dine **frie midler** på et almindeligt depot. 

Her skal du nemlig betale den fulde aktieskat på 27 % (og 42 % over progressionsgrænsen) hvert evig eneste år af din urealiserede gevinst. Det skaber et årligt likviditetsdræn, hvor du skal finde kontanter til skattefar i februar. Derfor skal den ultralave ÅOP på ETF'erne være ekstraordinært god for at opveje den fordel, du ellers kan hente ved skatteudskydelsen i de [danske realisationsbeskattede fonde](/danske-investeringsforeninger-fire-realisation/).

---

## De 3 topkandidater til mit setup

Når du skal vælge fonde til din ASK, din pension eller som en aggressiv pris-optimering af dine frie midler, kigger jeg lige nu specifikt på tre globale sværvægtere, som dækker markedet på forskellige måder:

### Amundi Prime All Country World UCITS ETF Acc (Prisbaskeren)
Dette er den nyeste og absolut billigste "alt-i-én"-fond på det europæiske marked. Hvis du vil have omkostningerne presset helt i bund, er det denne fond, du skal kigge på.
* **Ticker:** WEBN (Handelsvaluta: EUR) / ISIN: IE0003XJA0J9
* **ÅOP:** 0,07 %
* **Underliggende indeks:** *Solactive GBS Global Markets Large & Mid Cap Index*
* **Eksponering og markedsstørrelse:** Dækker store og mellemstore virksomheder (Large & Mid Cap) på tværs af 23 udviklede lande og 24 udviklingslande (Emerging Markets). Fonden fanger cirka 85-90 % af det samlede globale aktiemarked, men fravælger de mindre selskaber (Small Cap).
* **Argumenter for/imod:** En ÅOP på 0,07 % for en komplet global fond er intet mindre end revolutionerende. Ulemperne er minimale, men da fonden følger et Solactive-indeks i stedet for de traditionelle MSCI-indeks, kan der være mikroskopiske forskelle i sammensætningen, og fonden er relativt ny.

### iShares MSCI ACWI UCITS ETF USD (Acc) (Klassikeren)
BlackRocks flagskib inden for globale fonde og en absolut favorit på de danske aktiesparekonti gennem mange år.
* **Ticker:** IUSQ (Handelsvaluta: EUR) / ISIN: IE00B6R52259
* **ÅOP:** 0,20 %
* **Underliggende indeks:** *MSCI All Country World Index (ACWI)*
* **Eksponering og markedsstørrelse:** Ligesom WEBN dækker IUSQ både i-lande og u-lande (ca. 1.800 selskaber). Det er en rendyrket Large & Mid Cap fond, hvilket betyder, at de mindre Small Cap-virksomheder (som udgør de sidste ca. 10-15 % af verdensmarkedet) er skåret fra.
* **Argumenter for/imod:** Enorm likviditet, ekstremt tæt tracking og absolut tryghed hos verdens største pengeforvalter. Ulempen er, at en ÅOP på 0,20 % nu er næsten tre gange så dyr som WEBN, og du mangler stadig Small Cap-segmentet.

### SPDR MSCI ACWI IMI UCITS ETF (Det komplette marked)
Dette er den ultimative fond for investoren, der ikke vil nøjes med de store virksomheder, men som vil have det **komplette** marked i én enkelt handelsordre. 
* **Ticker:** SPYI (Handelsvaluta: EUR) / ISIN: IE00B3YLTY66
* **ÅOP:** 0,17 %
* **Underliggende indeks:** *MSCI ACWI IMI (All Country World Investable Market Index)*
* **Eksponering og markedsstørrelse:** Denne fond dækker over 4.900 selskaber på tværs af både udviklede markeder og udviklingslande. Det særlige ved "IMI"-indekset er, at det **inkluderer Small Cap**. Her ejer du altså både Large, Mid og Small Cap i én og samme fond og fanger dermed ca. 99 % af hele den globale aktiekage.
* **Argumenter for/imod:** Den absolut bredeste spredning overhovedet muligt i én fond uden behov for manuelle byggeklodser. Prisen på 0,17 % i ÅOP er yderst konkurrencedygtig. Tidligere var denne fond kapitalbeskattet, men dens skift over på SKATs positivliste gør den nu til en af de absolut stærkeste kandidater overhovedet til en Aktiesparekonto eller et pensionsdepot.

---

## Sammenligning: ETF'er på positivlisten vs. Danske Investeringsforeninger

| Egenskab | Udenlandske ETF'er (Positivliste) | Danske Investeringsforeninger (Reference) |
| :--- | :--- | :--- |
| **Primære anvendelse** | **Ideel til ASK og pensionsdepoter.** (Bør kun bruges sekundært til frie midler). | **Ideel til frie midler** (efter at ASK/pension er fyldt helt op). |
| **Skattetype** | Aktieindkomst (Lagerprincip) | Aktieindkomst (Realisationsprincip) |
| **Typisk ÅOP** | Ultralav (`[INDSÆT %]` - `[INDSÆT %]`) | Højere (`[INDSÆT %]` - `[INDSÆT %]`) |
| **Skattesats (frie midler)** | 27 % / 42 % (Betales årligt af urealiseret gevinst) | 27 % / 42 % (Betales ved salg / årligt af udbytte) |
| **Største fordel** | Laveste omkostninger = højere råt afkast | Skatteudskydelse på frie midler booster renters rente |
| **Største ulempe** | Likviditetsdræn ved frie midler (skat skal findes årligt) | Højere løbende gebyrer æder af afkastet over tid |

## Konklusion og næste skridt

Hvis du vil have det maksimale ud af de udenlandske ETF'er på positivlisten, skal du lade dem gøre det, de er bedst til: At agere motor på din Aktiesparekonto eller i dine pensionsdepoter. Her spiser de de danske investeringsforeninger råt på grund af den lave skattesats og den ultralave ÅOP.

Hvad foretrækker du? Har du allerede maxet din ASK ud med billige ETF'er, eller foretrækker du de traditionelle danske fonde? Del dine tanker i kommentarfeltet!